import java.util.Scanner;
public class Zad4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner wczytaj = new Scanner(System.in);
double a, b, c, srednia, wynik;
System.out.println("Podaj wynik pierwszego testu: ");
a = wczytaj.nextDouble();
System.out.println("Podaj wynik drugiego testu: ");
b = wczytaj.nextDouble();

System.out.println("Podaj wynik trzeciego testu: ");
c = wczytaj.nextDouble();

wynik = a + b + c;
srednia = wynik/3;

if(srednia>90) {
	System.out.println("5");
}
else if(srednia>=80 || srednia <=89) {
	System.out.println("4");
}
else if(srednia>=70 || srednia <=79) {
	System.out.println("3");
	
}
else if(srednia >=60 || srednia <=69) {
	System.out.println("2");
	
}
else if(srednia < 60) {
	System.out.println("1");
}
wczytaj.close();
	}

}
