import java.util.Scanner;
public class Zad2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner wczytaj = new Scanner(System.in);
	
		int a, b, c;
		System.out.println("Podaj dzien w formie liczby: ");
		a = wczytaj.nextInt();
		
		System.out.println("Podaj miesiac w formie liczby: ");
		b = wczytaj.nextInt();
		
		System.out.println("Podaj dwie ostatnie liczby roku: ");
		c = wczytaj.nextInt();
		
		if(a*b==c) {
		System.out.println("Data jest magiczna.");	
		}
		else {
			System.out.println("Data nie jest magiczna.");
			wczytaj.close();
		}
		}

}
