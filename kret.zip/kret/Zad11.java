import java.util.Scanner;
public class Zad11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner wczytaj = new Scanner(System.in);
		String a,b,c;
		double czas,czas2,czas3;
		System.out.println("Podaj nazwisko pierwszego biegacza");
		a=wczytaj.nextLine();
		System.out.println("Podaj nazwisko drugiego biegacza");
		b=wczytaj.nextLine();
		System.out.println("Podaj nazwisko trzeciego biegacza");
		c=wczytaj.nextLine();

		System.out.println("Podaj czas pierwszego biegaczas");
		czas=wczytaj.nextDouble();
		System.out.println("Podaj czas drugiego biegacza");
		czas2=wczytaj.nextDouble();
		System.out.println("Podaj czas trzeciego biegacza");
		czas3=wczytaj.nextDouble();

		if (czas<czas2&&czas<czas3&&czas2<czas3) {
		System.out.println("Nr1: " + a + "Nr2: " + b + "Nr3: " + c);
		}
		else if (czas>czas2&&czas<czas3&&czas2<czas3) {
		System.out.println("Nr1: " + b + "Nr2: " + a + "Nr3: " + c);
		}
		else if (czas<czas2&&czas>czas3&&czas2>czas3) {
		System.out.println("Nr1: " + c + "Nr2: " + a + "Nr3: " + b);
		}
		else if (czas<czas2&&czas<czas3&&czas2>czas3) {
		System.out.println("Nr1: " + a + "Nr2" + c + "Nr3: " + b);
		}
		else if (czas>czas2&&czas>czas3&&czas2<czas3) {
		System.out.println("Nr1: " + b + "Nr2: " + c + "Nr3: " + a);
		}
		else if (czas>czas2&&czas>czas3&&czas2<czas3) {
		System.out.println("Nr1: "+ c + "Nr2: " + b + "Nr3: " + c );
		}
		wczytaj.close();
		}
	
	

		}
