import java.util.Scanner;
public class Zad13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner wczytaj = new Scanner(System.in);
		
		
		String A = "A",B = "B",C="C";
		double wynik=0,minuty=0;
		
		System.out.println("Wybierz taryfe: [A] [B] [C] - Wpisz poni�ej (Bez Nawias�w)!");
		String wybor = wczytaj.nextLine();
		
		if (wybor.equals(A)) {
			
			System.out.println("Wybra�e� A! Podaj ilosc minut!: ");
			minuty = wczytaj.nextDouble();
			
			wynik = minuty - 450;
			wynik = wynik * 0.45;
			wynik = wynik + 39.99;
			

			
			System.out.println("Op�ata za dany miesi�c: "+wynik+" z�");
			
			
		} else if (wybor.equals(B)) {
			
			System.out.println("Wybra�e� B! Podaj ilosc minut!: ");
			minuty = wczytaj.nextDouble();
			
			wynik = minuty - 900;
			wynik = wynik * 0.40;
			wynik = wynik + 69.99;
			

			System.out.println("Op�ata za dany miesi�c: "+wynik+" z�");
			
			
		}else if (wybor.equals(C)) {
			
			System.out.println("Wybra�e� C Podaj ilosc minut!: ");
			minuty = wczytaj.nextDouble();
			
			wynik = wynik+69.99;
			

			
			System.out.println("Op�ata za dany miesi�c: "+wynik+" z�");
			
		} else {
			
			
			System.out.println("Niepoprawny wyb�r!");
		}
		
			
wczytaj.close();

	}

}
