import java.util.Scanner;
public class Zad12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner wczytaj = new Scanner(System.in);
		
		String water = "WODA",air = "POWIETRZE",steel="STAL";
		double czas=0,odleglosc=0;
		
		System.out.println("Wybierz 1: [WODA] [POWIETRZE] [STAL] - Wpisz poni�ej (Bez Nawias�w)!");
		String wybor = wczytaj.nextLine();
		
		if (wybor.equals(water)) {
			
			System.out.println("Wybra�e� Wode! Podaj odleglosc!: ");
			odleglosc = wczytaj.nextDouble();
			
			czas = czas + odleglosc/1490;
			
			System.out.println("Wynik to: "+czas);
			
			
		} else if (wybor.equals(air)) {
			
			System.out.println("Wybra�e� Powietrze! Podaj odleglosc!: ");
			odleglosc = wczytaj.nextDouble();
			
			czas = czas + odleglosc/343;
			System.out.println("Wynik to: "+czas);
			
			
		}else if (wybor.equals(steel)) {
			
			System.out.println("Wybra�e� Stal! Podaj odleglosc!: ");
			odleglosc = wczytaj.nextDouble();
			
			czas = czas + odleglosc/5100;
			
			System.out.println("Wynik to: "+czas);
			
		} else {
			
			
			System.out.println("Niepoprawny wyb�r!");
		}
		
			
wczytaj.close();

	}

}
