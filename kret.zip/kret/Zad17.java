import java.util.Scanner;
public class Zad17 {

 public static void main(String[] args) {

    Scanner wczytaj = new Scanner(System.in);

    

    String odpowiedz;

    String tak = "tak";

    String nie = "nie";

    

    boolean wegetarianskie = true;

    boolean weganskie = true ;

    boolean bezglutenowe = true;

    

    System.out.println("Czy sa jacys wegetarianie?");

    odpowiedz = wczytaj.nextLine();

    if(odpowiedz.compareToIgnoreCase(tak)==0) {

        wegetarianskie =true;    

    }

    else if(odpowiedz.compareToIgnoreCase(nie)==0) {

        wegetarianskie = false;

    }

    else {

        System.out.println("Wprowadzono zla odpowiedz");

    }

    

    System.out.println("Czy sa jacys weganie?");

    odpowiedz = wczytaj.nextLine();

    if(odpowiedz.compareToIgnoreCase(tak)==0) {

        weganskie =true;    

    }

    else if(odpowiedz.compareToIgnoreCase(nie)==0) {

        weganskie = false;

    }

    else {

        System.out.println("Wprowadzono zla odpowiedz");

    }

    System.out.println("Czy sa jacys bezglutenowcy?");

    odpowiedz = wczytaj.nextLine();

    if(odpowiedz.compareToIgnoreCase(tak)==0) {

        bezglutenowe =true;    

    }

    else if(odpowiedz.compareToIgnoreCase(nie)==0) {

        bezglutenowe = false;

    }

    else {

        System.out.println("Wprowadzono zla odpowiedz");

    }

    

    if(wegetarianskie==true) {

        if(weganskie==true) {

            if(bezglutenowe==true) {

                System.out.println("Mozecie sie wybrac do nastepjacych restauracji:");

                System.out.print("Kawiarnia na Rogu \nKawiarnia u Szefa");

            }

            else {

                System.out.println("Mozecie sie wybrac do nastepjacych restauracji:");

                System.out.print("Kawiarnia na Rogu \nKawiarnia u Szefa");

            }

        }

        else {

            if(bezglutenowe==true) {

                System.out.println("Mozecie sie wybrac do nastepjacych restauracji:");

                System.out.print("Kawiarnia na Rogu \nKawiarnia u Szefa \nPizzeria przy Dworcowej");

            }

            else {

                System.out.println("Mozecie sie wybrac do nastepjacych restauracji:");

                System.out.print("Kawiarnia na Rogu \nKawiarnia u Szefa \nPizzeria przy Dworcowej \nWloskie Specjaly");

            }

        }

    }

    else {

        if(weganskie==true) {

            if(bezglutenowe==true) {

                System.out.println("Mozecie sie wybrac do nastepjacych restauracji:");

                System.out.print("Kawiarnia na Rogu \nKawiarnia u Szefa");

            }

            else {

                System.out.println("Mozecie sie wybrac do nastepjacych restauracji:");

                System.out.print("Kawiarnia na Rogu \nKawiarnia u Szefa");

            }

        }

        else {

            if(bezglutenowe==true) {

                System.out.println("Mozecie sie wybrac do nastepjacych restauracji:");

                System.out.print("Kawiarnia na Rogu \nKawiarnia u Szefa \nPizzeria przy Dworcowej");

            }

            else {

                System.out.println("Mozecie sie wybrac do nastepjacych restauracji:");

                System.out.print("Kawiarnia na Rogu \nKawiarnia u Szefa \nPizzeria przy Dworcowej \nWloskie Specjaly \nLuksusuwe Burgery u Jacka");

            }

        }

        

    }

    

    wczytaj.close();

    

}



}


