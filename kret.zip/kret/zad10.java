import java.util.Scanner;
public class zad10 {

	

	public static void main(String[] args) {
	// TODO Auto-generated method stub
	Scanner wczytaj = new Scanner(System.in);

	double kalorie,gramy,kalorieztluszczu,procentkalorii;
	System.out.println("Wprowadz liczbe kalorii w produkcie");
	kalorie = wczytaj.nextDouble();

	System.out.println("Wprowadz liczbe gramow w produkcie");
	gramy=wczytaj.nextDouble();

	kalorieztluszczu = gramy*9;
	procentkalorii=kalorieztluszczu/kalorie;



	if(procentkalorii<0.3*kalorie) {
	System.out.println("Produkt jest niskotluszczowy");
	}
	else {
	System.out.println("Produkt nie jest niskotluszczowy");
	wczytaj.close();
	}
	}


	}
