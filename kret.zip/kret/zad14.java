import java.util.Scanner;
public class zad14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner wczytaj = new Scanner(System.in);
		
		
		String A = "A",B = "B",C="C";
		double wynik=0,minuty=0,wynik2=0,wynik3=0,wynik4=0;
		
		System.out.println("Wybierz taryfe: [A] [B] [C] - Wpisz poni�ej (Bez Nawias�w)!");
		String wybor = wczytaj.nextLine();
		
		if (wybor.equals(A)) {
			
			System.out.println("Wybra�e� A! Podaj ilosc minut!: ");
			minuty = wczytaj.nextDouble();
			
			wynik = minuty - 450;
			wynik = wynik * 0.45;
			wynik = wynik + 39.99;
			

			
			System.out.println("Op�ata za dany miesi�c: "+wynik+" z�");
			
			wynik2 = wynik * 0.40;
			wynik2 = wynik + 59.99;
			wynik4 = wynik4 + wynik;
			wynik2 = wynik2 - wynik;
			
			System.out.println("Kupujac pakiet B zaoszcz�dzisz "+wynik2+" z�"
);
			wynik3 = wynik3 + 69.99;
			wynik3= wynik4 - wynik3;
			
			System.out.println("Kupujac pakiet C zaoszcz�dzisz "+wynik3+" z�");
			
			
		} else if (wybor.equals(B)) {
			
			System.out.println("Wybra�e� B! Podaj ilosc minut!: ");
			minuty = wczytaj.nextDouble();
			
			wynik = minuty - 900;
			wynik = wynik * 0.40;
			wynik = wynik + 59.99;
			

			System.out.println("Op�ata za dany miesi�c: "+wynik+" z�");
			
			wynik3 = wynik3 + 69.99;
			wynik3= wynik3 - wynik;
			
			System.out.println("Kupujac pakiet C zaoszcz�dzisz"+wynik3+"z�");
			
			
		}else if (wybor.equals(C)) {
			
			System.out.println("Wybra�e� C Podaj ilosc minut!: ");
			minuty = wczytaj.nextDouble();
			
			wynik = wynik+69.99;
			

			
			System.out.println("Op�ata za dany miesi�c: "+wynik+" z�");
			
		} else {
			
			
			System.out.println("Niepoprawny wyb�r!");
		}
		
			
wczytaj.close();

	}

}
