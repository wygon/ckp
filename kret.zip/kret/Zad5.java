import java.util.Scanner;
public class Zad5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner wczytaj = new Scanner(System.in);
		
		System.out.println("Podaj mase obiektu!: ");
		double masa = wczytaj.nextDouble();
		
		masa = masa * 9.8;
		
		if (masa > 1000) {
			
			System.out.println("Obiekt jest, za ci�ki! -- "+masa);
			
		} else if (masa < 10) {
			
			System.out.println("Obiekt jest za lekki -- "+masa);
		} else {
			
			System.out.println("Przedmiot wa�y -- "+masa);
		}
		wczytaj.close();
		
		

	}

}
