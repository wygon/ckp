import java.util.Scanner;
public class Zad8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner wczytaj = new Scanner(System.in);
int liczba;
System.out.println("Wprowadz liczbe sztuk: ");
liczba=wczytaj.nextInt();

if(liczba >10 || liczba <19) {
	System.out.println("Rabat 20%");
}
else if( liczba>20 || liczba <49) {
	System.out.println("Rabat 30%");
}
else if(liczba>50||liczba<99) {
	System.out.println("Rabat 40%");
}
else if(liczba >=100) {
	System.out.println("Rabat 50%");
}
wczytaj.close();
	}

}
