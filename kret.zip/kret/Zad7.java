import java.util.Scanner;
public class Zad7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner wczytaj = new Scanner(System.in);
		
		
		
		String imie1,imie2,imie3;
		
		System.out.println("Podaj 1 imie: ");
		imie1 = wczytaj.nextLine();
		System.out.println("Podaj 2 imie: ");
		imie2 = wczytaj.nextLine();
		System.out.println("Podaj 3 imie: ");
		imie3 = wczytaj.nextLine();
		
		if (imie1.compareToIgnoreCase(imie2) < 0) {
			
			if (imie1.compareToIgnoreCase(imie3) < 0) {
				{
					if (imie2.compareTo(imie3)< 0)	{
						
						System.out.println(imie1+imie2+imie3);
					}
				}
				
				
				
				
			} else if (imie3.compareToIgnoreCase(imie2) < 0) {
				
				System.out.println(imie1+imie3+imie2);
				
				
			}
		} else if (imie3.compareToIgnoreCase(imie1) < 0) {
			
			System.out.println(imie2+imie3+imie1);
			
		}
		
		wczytaj.close();
		
	}

}
