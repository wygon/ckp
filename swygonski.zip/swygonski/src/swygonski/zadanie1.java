package swygonski;

public class zadanie1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String name = "Szymon Wygoński";

int age = 99;

double annualPay = 180000;

System.out.println("Nazywam sie "+name+", mam "+age+" i chce zarabiac "+annualPay+" zlotych rocznie.");
	}

}
