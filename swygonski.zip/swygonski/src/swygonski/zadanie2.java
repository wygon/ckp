package swygonski;

public class zadanie2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String firstName = "Szymon";
		String middleName = "Michal";
		String lastName = "Wygonski";
		
		char fi = firstName.charAt(0);
		char mi = middleName.charAt(0);
		char li = lastName.charAt(0);
	
		System.out.println(firstName + " " + middleName + " " + lastName);
		System.out.println(fi +" "+ mi + " " + li);
	}

}
